<?php

namespace App\Http\Controllers;
use App\Students;
use Illuminate\Http\Request;
use App\Http\Requests;
use App\Http\Controllers\Controller;
use Illuminate\Support\Facades\DB;

class StudentsController extends Controller
{
    public function showForm(Request $request){
        $students = Students::all();
    	return view ('student-registration', compact('students'));
    }


    public function completeForm(Request $request){
    	$full_name = $request->full_name;
        $course = $request->course;
        $student_number = $request->student_number;

        $student = new students; 
        $student->full_name = $full_name;
        $student->course = $course;
        $student->student_number = $student_number;
        $student->save();

    	return view ('complete-registration');
    }

    public function showList(){
        $users = Students::all();
        return view('show-list', compact('users'));
    }

    public function editStudent(Request $request, $id){
        $student = Students::find($id);
        return view('/edit-student', compact('student'));
    }
    public function saveEdit(Request $request){
        $id = $request->id;
        $full_name = $request->full_name;
        $course = $request->course;
        $student_number = $request->student_number;

        $student = Students::find($id);
        $student->id = $id;
        $student->full_name = $full_name;
        $student->course = $course;
        $student->student_number = $student_number;
        $student->save();

        return redirect('/show-list');
    }

    public function toDelete(Request $request, $id){
        $student = Students::find($id);
        $student->delete();
        return redirect('/show-list');
        
    }
}
