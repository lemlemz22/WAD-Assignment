<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

use App\Http\Requests;

class RegistrationController extends Controller
{
    public function finishRegisterForm (Request $request){
  	return view ('succesful-register');
	}
}
