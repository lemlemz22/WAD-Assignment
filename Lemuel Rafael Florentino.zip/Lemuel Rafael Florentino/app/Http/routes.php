<?php

Route::get('/' , 'StudentsController@showForm');
Route::post('/complete-registration' , 'StudentsController@completeForm');
Route::post('/succesful-register', 'RegistrationController@finishRegisterForm');

Route::post('/add-students' , 'StudentsController@showForm');
Route::post('/show-list' , 'StudentsController@showList');

Route::get('/edit-student/{id}', 'StudentsController@editStudent');



Route::auth();