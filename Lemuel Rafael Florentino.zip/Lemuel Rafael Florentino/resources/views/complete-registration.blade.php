<!DOCTYPE html>
<html>
<head>
	<title>Registration Complete</title>
	<link rel="stylesheet" type="text/css" href="/Bootstrap/css/bootstrap.min.css">
</head>
<body>
<center>
<h1>Registration Complete</h1>
<br>

	<a href="/add-students"><button class="btn" type="submit">ADD Students</button></a>

	<a href="/show-list"><button class="btn" type="submit">All Students</button></a>
</center>

</body>
</html>