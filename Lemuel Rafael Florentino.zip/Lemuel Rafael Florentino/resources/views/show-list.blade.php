<!DOCTYPE html>
<html>
<head>
	<title>All Students</title>
	<link rel="stylesheet" type="text/css" href="/Bootstrap/css/bootstrap.min.css">
<style>
	
th{
	text-align: center;
}	
</style>

</head>
<body>
<center>
	<table class="table-bordered table-hover table" style="text-align:center">
		<thead>
			<tr>
				<th hidden> ID </th>
				<th> Full Name </th>
				<th> Course </th>
				<th> Student # </th>
				<th> Options </th>
			</tr>
		</thead>

		<tbody>
			<?php foreach ($users as $user):
			?>
			<tr>
				<td hidden>$user->id ?> </td>
				<td> {{ $user->full_name }}</td>
				<td> {{ $user->course }}</td>
				<td> {{ $user->student_number }} </td>
				<td>
					<a href="/edit/{{ $user->id }}">
						<button class="btn btn-success" class="fa fa-pencil">Edit</button>
						</a>
					<a href="/delete/{{ $user->id }}">
						<button class="btn btn-danger" class="fa fa-trash">Delete</button>
					</a>
						
				</td>
			</tr>
			<?php endforeach; ?>
		</tbody>
	</table>
	<br>
	<a href="/add-students"><button class="btn btn-primary" type="submit">Add Students</button></a><br><br>
</center>
</body>
</html>