<!DOCTYPE html>
<html>
<head>
	<title>Edit Student</title>
	<link rel="stylesheet" type="text/css" href="/Bootstrap/css/bootstrap.min.css">
</head>
<body> <center>
<h1>EDIT STUDENTS</h1>
<form method="POST" action="/save-edit">
{{ csrf_field() }}
	<input type="text" name="id" value="{{ $student->id }}" hidden>
	Full Name: <input type="text" name="full_name" value="{{ $student->full_name }}"><br>
	Course: <input type="text" name="course" value="{{ $student->course }}"><br>
	Student #: <input type="text" name="student_number" value="{{ $student->student_number }}"><br>
	<button class="btn btn-success">Save</button>
</form>
</center>

</body>
</html>