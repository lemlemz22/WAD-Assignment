<?php

Route::get('/' , 'StudentsController@showForm');
Route::post('/complete-registration' , 'StudentsController@completeForm');
Route::get('/succesful-register', 'RegistrationController@finishRegisterForm');

Route::get('/add-students' , 'StudentsController@showForm');
Route::get('/show-list' , 'StudentsController@showList');
Route::get('/edit/{id}', 'StudentsController@editStudent');
Route::post('/save-edit', 'StudentsController@saveEdit');
Route::get('/delete/{id}', 'StudentsController@toDelete');



Route::auth();